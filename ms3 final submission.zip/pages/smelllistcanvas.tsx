import ListSmell from '../components/listsmell';

export default function SmellListCanvas() {
    
    // type Props = { readonly smellTitle: SmellTitle}

    
    return (
        <ListSmell/>  
    );
  }