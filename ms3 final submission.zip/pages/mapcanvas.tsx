import BigMap from '../components/bigmap';

export default function MapCanvas() {
   
    return(   
           <BigMap/>          
    )

}