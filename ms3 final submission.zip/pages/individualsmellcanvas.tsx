export default function InvididualSmellCanvas() {
    return (
        <h1>This is the individual smell canvas</h1>
    );
}