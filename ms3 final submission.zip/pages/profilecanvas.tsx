import Profile from "../components/profile"
import Component from "../components/testlocation"

export default function ProfileCanvas() {
    return (
       // <h1>This is the profile canvas</h1>
        <Profile />

    );
  }