import BigMap from '../components/bigmap';

const Home = () => {
  return (
    <div>
      <BigMap></BigMap>
    </div>
  )
}

export default Home
