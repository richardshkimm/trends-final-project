import Smell from '../components/smell';


export default function AddSmellCanvas() {
    return(   
           <Smell/>          
    )

}